import React from 'react'

const Dashboard = () => {
  return (
    <div className='mt-2'>Dashboard</div>
  )
}

export default Dashboard