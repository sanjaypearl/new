import {
  ExceptionFilter,
  Catch,
  ArgumentsHost,
  HttpException,
  HttpStatus,
  Logger, // For logging errors
} from '@nestjs/common';
import { Request, Response } from 'express';

@Catch(HttpException) // Catch only HttpException instances
export class HttpExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger(HttpExceptionFilter.name);

  catch(exception: HttpException, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest<Request>();
    const status = exception.getStatus();
    const errorResponse = exception.getResponse(); // Get NestJS's default error object

    // Determine the message - can be a string or an array of strings (from ValidationPipe)
    const message =
      typeof errorResponse === 'object'
        ? (errorResponse as any).message || 'An unexpected error occurred.'
        : errorResponse || 'An unexpected error occurred.';

    const formattedError = {
      statusCode: status,
      timestamp: new Date().toISOString(),
      path: request.url,
      method: request.method,
      error: typeof errorResponse === 'object' ? (errorResponse as any).error : 'Internal Server Error', // Keep original error name or default
      message: Array.isArray(message) ? message.join(', ') : message, // Join array messages for cleaner output
    };

    // Log the error
    this.logger.error(
      `HTTP Error: ${status} - ${request.method} ${request.url}`,
      exception.stack,
      JSON.stringify(formattedError),
    );

    response.status(status).json(formattedError);
  }
}