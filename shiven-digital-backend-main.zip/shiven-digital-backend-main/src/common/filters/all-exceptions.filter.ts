import {
  Catch,
  ArgumentsHost,
  HttpException,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import { BaseExceptionFilter } from '@nestjs/core';
import { Request, Response } from 'express';

@Catch() // Catch all exceptions
export class AllExceptionsFilter extends BaseExceptionFilter {
  private readonly logger = new Logger(AllExceptionsFilter.name);

  catch(exception: unknown, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest<Request>();

    let status = HttpStatus.INTERNAL_SERVER_ERROR;
    let message: string | string[] = 'Internal server error.'; // Default message
    let errorName: string = 'Internal Server Error';

    // 1. Handle HttpException (e.g., BadRequestException, UnauthorizedException, NotFoundException etc.)
    if (exception instanceof HttpException) {
      status = exception.getStatus();
      const errorResponse = exception.getResponse(); // This can be a string or an object

      if (typeof errorResponse === 'string') {
        message = errorResponse;
        errorName = exception.name; // Use exception.name for error type
      } else if (typeof errorResponse === 'object' && errorResponse !== null) {
        // This handles ValidationPipe errors (which return { message: string[], error: string, statusCode: number })
        message = (errorResponse as any).message || message;
        errorName = (errorResponse as any).error || exception.name; // Use 'error' field or exception.name
      }
    }
    // 2. Handle standard JavaScript Errors
    else if (exception instanceof Error) {
      status = HttpStatus.INTERNAL_SERVER_ERROR; // Or a more specific status if you map them
      message = exception.message || 'An unexpected error occurred.';
      errorName = exception.name || 'Error';
    }
    // 3. Handle anything else (e.g., a string, number, or plain object thrown)
    else if (typeof exception === 'string') {
      message = exception;
      errorName = 'Error'; // Generic error name for strings
    }
    // For any other unknown thrown values
    else {
      message = 'An unknown error occurred.';
      errorName = 'UnknownError';
    }

    const formattedError = {
      statusCode: status,
      timestamp: new Date().toISOString(),
      path: request.url,
      method: request.method,
      error: errorName,  
      message: Array.isArray(message) ? message.join(', ') : message,  
      success: false,
    };

    this.logger.error(
      `Caught unexpected error: ${status} - ${request.method} ${request.url}`,
      exception instanceof Error ? exception.stack : JSON.stringify(exception), 
      JSON.stringify(formattedError),
    );

    response.status(status).json(formattedError);
  }
}