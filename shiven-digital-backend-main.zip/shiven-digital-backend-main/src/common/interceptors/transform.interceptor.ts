import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

// Define a consistent response structure
export interface ApiResponse<T> { // Renamed to ApiResponse to avoid conflict with 'Response' from express
  statusCode: number;
  message: string; // Made required for consistency
  success: boolean;
  data: T;
}

@Injectable()
export class TransformInterceptor<T> implements NestInterceptor<T, ApiResponse<T>> {
  intercept(
    context: ExecutionContext,
    next: CallHandler,
  ): Observable<ApiResponse<T>> {
    return next.handle().pipe(
      map((originalData) => {
        // Create a new object for the 'data' payload to avoid modifying the original
        let dataPayload: T;
        let responseMessage: string = 'Success'; // Default success message

        // Check if originalData is an object and has a 'message' property
        if (originalData && typeof originalData === 'object' && 'message' in originalData) {
          // Extract the message from the originalData
          responseMessage = (originalData as any).message; // Cast to any to access message
          
          // Create a new object for dataPayload, excluding the 'message' property
          // This ensures 'message' doesn't appear inside 'data'
          const { message, ...rest } = originalData as any;
          dataPayload = rest as T;
        } else {
          // If no 'message' in originalData, use the originalData as is for the payload
          dataPayload = originalData;
        }

        return {
          statusCode: context.switchToHttp().getResponse().statusCode,
          message: responseMessage,
          success: true,
          data: dataPayload,
        };
      }),
    );
  }
}