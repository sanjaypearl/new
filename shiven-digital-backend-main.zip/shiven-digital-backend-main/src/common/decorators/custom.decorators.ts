import { createParamDecorator, ExecutionContext, SetMetadata } from '@nestjs/common';
import mongoose, { Types } from 'mongoose';
import { Request } from 'express';

export const Id = createParamDecorator(
  (_: unknown, ctx: ExecutionContext): Types.ObjectId | undefined => {
    const request = ctx.switchToHttp().getRequest<Request>(); // Use generic for Request type
    if (mongoose.isValidObjectId(request.sub)) { // Check if sub exists before validating
      return new Types.ObjectId(request.sub); // request.sub is now typed as string | undefined
    }
    return undefined;
  },
);

export const Email = createParamDecorator(
  (_: unknown, ctx: ExecutionContext): string | undefined => { // Add return type for clarity
    const request = ctx.switchToHttp().getRequest<Request>();
    return request.email; // request.email is now typed as string | undefined
  },
);

export const Role = createParamDecorator(
  (_: unknown, ctx: ExecutionContext): string | undefined => { 
    const request = ctx.switchToHttp().getRequest<Request>();
    return request.role; 
  },
);



export const ROLES_KEY = 'roles'; 
export const Roles = (...roles: string[]) => SetMetadata(ROLES_KEY, roles);