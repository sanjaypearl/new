// src/common/guards/roles.guard.ts
import { Injectable, CanActivate, ExecutionContext } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Request } from 'express'; // Import Request type
import { ROLES_KEY } from '../decorators/custom.decorators';

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    // 1. Get the required roles for this route from the @Roles() decorator
    const requiredRoles = this.reflector.getAllAndOverride<string[]>(
      ROLES_KEY,
      [context.getHandler(), context.getClass()],
    );

    // If no @Roles() decorator is present, the route is accessible to all authenticated users
    if (!requiredRoles) {
      return true;
    }

    // 2. Get the authenticated user's role from the request object
    // Assuming AuthTokenMiddleware has attached `req.role`
    const request = context.switchToHttp().getRequest<Request>();
    const userRole = request.role; // This is populated by AuthTokenMiddleware

    // 3. Check if the user's role is among the required roles
    // For simplicity, we'll assume a single role per user.
    // For multiple roles, you might use: requiredRoles.some(role => userRoles.includes(role));
    if(!userRole) return false
    return requiredRoles.includes(userRole);
  }
}