import {
  IsEmail,
  IsNotEmpty,
  IsString,
  IsEnum,
  IsOptional,
  MinLength,
} from 'class-validator';

export enum UserRole {
  Admin = 'admin',
  AdminStaff = 'adminstaff',
  Agency = 'agency',
  AgencyStaff = 'agency staff',
  Customer = 'customer',
}

export class CreateUserDto {
  @IsEmail()
  @IsNotEmpty()
  email: string;

  @IsString()
  @IsNotEmpty()
  userName: string;

  @IsString()
  @IsNotEmpty()
  @MinLength(6, { message: 'Password must be at least 6 characters long.' })
  password: string;

  @IsEnum(Object.values(UserRole), {
    message:
      'Invalid role provided. Must be one of: admin, adminstaff, agency, agency staff, customer.',
  })
  role: UserRole;
}
