import { ConflictException, Injectable, BadRequestException, NotAcceptableException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { User, UserDocument } from './user.schema'; 
import { Model, Types } from 'mongoose';
import { CreateUserDto } from './dto/user.dto'; 
import * as bcrypt from 'bcrypt';

@Injectable()
export class UserService {
  constructor(@InjectModel(User.name) private userModel: Model<UserDocument>) {}

  async createUser(data: CreateUserDto) {
    // 1. Check for duplicate email
    const existingUser = await this.userModel.findOne({ email: data.email }).exec();
    if (existingUser) {
      throw new ConflictException('User with this email already exists.');
    }

    if(data.role === 'admin'){
      throw new NotAcceptableException("Admin Role is Not Allowed")
    }

   
    const saltRounds = 10; 
    const hashedPassword = await bcrypt.hash(data.password, saltRounds);

    const createdUser = new this.userModel({
      userName: data.userName,
      email: data.email,
      password: hashedPassword,
      role: data.role,
    });

    const user = await createdUser.save();

    const { password, ...result } = user.toObject(); 

    return {
      user : result
    };
  }

  

  // Example of finding a user by email, useful for login
  async findByEmail(email: string): Promise<UserDocument | null> {
    return this.userModel.findOne({ email }).exec();
  }

  async findByEmailWithPassword(email: string): Promise<UserDocument | null> {
    return this.userModel.findOne({ email }).select('+password').exec();
  }

   async findById(id: Types.ObjectId): Promise<UserDocument | null> {
    return this.userModel.findById(id).exec();
  }

  // Method to update user's refresh token
  async updateRefreshToken(userId: Types.ObjectId, refreshToken: string | null): Promise<void> {
    await this.userModel.findByIdAndUpdate(userId, { refreshToken }).exec();
  }
}