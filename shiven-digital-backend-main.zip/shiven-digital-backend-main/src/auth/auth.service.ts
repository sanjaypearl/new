// import {
//   Injectable,
//   NotFoundException,
//   UnauthorizedException,
// } from '@nestjs/common';
// import { UserService } from '../user/user.service';
// import * as bcrypt from 'bcrypt';
// import { JwtService } from '@nestjs/jwt';
// import { ConfigService } from '@nestjs/config';
// import { Types } from 'mongoose'; // For ObjectId
// import { LoginDto } from './dto/auth.dto';

// @Injectable()
// export class AuthService {
//   constructor(
//     private userService: UserService,
//     private jwtService: JwtService,
//     private configService: ConfigService,
//   ) {}

//   async validateUser(email: string, pass: string): Promise<any | null> {
//     const user = await this.userService.findByEmailWithPassword(email);
//     if (!user) {
//       return null;
//     }

//     const isPasswordMatch = await bcrypt.compare(pass, user.password);
//     if (!isPasswordMatch) {
//       return null;
//     }

//     // Return user without password
//     const { password, ...result } = user.toObject();
//     return result;
//   }

//   async hashData(data: string): Promise<string> {
//     const saltRounds = 10;
//     return bcrypt.hash(data, saltRounds);
//   }

//   async getTokens(userId: Types.ObjectId, email: string, role: string) {
//     const [accessToken, refreshToken] = await Promise.all([
//       this.jwtService.signAsync(
//         {
//           sub: userId.toHexString(), 
//           email,
//           role,
//         },
//         {
//           secret: this.configService.get<string>('JWT_ACCESS_SECRET'),
//           expiresIn: this.configService.get<string>('JWT_ACCESS_EXPIRATION'), 
//         },
//       ),
//       this.jwtService.signAsync(
//         {
//           sub: userId.toHexString(),
//           email,
//           role,
//         },
//         {
//           secret: this.configService.get<string>('JWT_REFRESH_SECRET'),
//           expiresIn: this.configService.get<string>('JWT_REFRESH_EXPIRATION'), 
//         },
//       ),
//     ]);

//     return {
//       accessToken,
//       refreshToken,
//     };
//   }

//   async updateRefreshToken(
//     userId: Types.ObjectId,
//     refreshToken: string | null,
//   ): Promise<void> {
//     if (refreshToken) {
//       const hashedRefreshToken = await this.hashData(refreshToken);
//       await this.userService.updateRefreshToken(userId, hashedRefreshToken);
//     } else {
//       await this.userService.updateRefreshToken(userId, null); // Clear refresh token on logout
//     }
//   }

//   async refreshTokens(
//     userId: Types.ObjectId,
//     refreshToken: string,
//   ) {
//     const user = await this.userService.findById(userId);

//     if (!user || !user.refreshToken) {
//       throw new UnauthorizedException(
//         'Access Denied: User not found or refresh token missing.',
//       );
//     }

//     // Compare the provided refresh token with the one stored in the database
//     const refreshTokenMatches = await bcrypt.compare(
//       refreshToken,
//       user.refreshToken,
//     );
//     if (!refreshTokenMatches) {
//       throw new UnauthorizedException('Access Denied: Invalid refresh token.');
//     }

//     // If valid, generate new tokens
//     const tokens = await this.getTokens(user._id, user.email, user.role);
//     await this.updateRefreshToken(user._id, tokens.refreshToken); // Store the new hashed refresh token
//     return tokens;
//   }

//   async signIn(signInDto: LoginDto) {
//     const user = await this.userService.findByEmailWithPassword(
//       signInDto.email,
//     );
//     if (!user) {
//       throw new NotFoundException('Incorrect E-Mail');
//     }

//     const matchPassword = await bcrypt.compare(
//       signInDto.password,
//       user.password,
//     );

//     if (!matchPassword) {
//       throw new NotFoundException('Incorrect Password');
//     }

//     const userWithoutPassword = await this.userService.findByEmail(
//       signInDto.email,
//     );
//     if (!userWithoutPassword) return {};
//     const result = userWithoutPassword.toObject();

//     const tokens = await this.getTokens(
//       userWithoutPassword._id,
//       userWithoutPassword.email,
//       userWithoutPassword.role,
//     );
//     await this.updateRefreshToken(userWithoutPassword._id, tokens.refreshToken);

//     return {
//       userData: result,
//       tokens,
//     };
//   }
// }


import {
  Injectable,
  NotFoundException,
  UnauthorizedException,
} from '@nestjs/common';
import { UserService } from '../user/user.service';
import * as bcrypt from 'bcrypt';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { Types } from 'mongoose';
import { LoginDto } from './dto/auth.dto';

@Injectable()
export class AuthService {
  constructor(
    private userService: UserService,
    private jwtService: JwtService,
    private configService: ConfigService,
  ) {}

  /**
   * Validate user credentials
   * Returns user data without password if valid, otherwise null
   */
  async validateUser(email: string, pass: string): Promise<any | null> {
    const user = await this.userService.findByEmailWithPassword(email);
    if (!user) return null;

    const isPasswordMatch = await bcrypt.compare(pass, user.password);
    if (!isPasswordMatch) return null;

    const { password, ...result } = user.toObject();
    return result;
  }

  /**
   * Hash any string (used for refresh tokens)
   */
  async hashData(data: string): Promise<string> {
    const saltRounds = 10;
    return bcrypt.hash(data, saltRounds);
  }

  /**
   * Generate both access and refresh JWT tokens
   */
  async getTokens(userId: Types.ObjectId, email: string, role: string) {
    const [accessToken, refreshToken] = await Promise.all([
      // Access Token
      this.jwtService.signAsync(
        { sub: userId.toHexString(), email, role },
        {
          secret: this.configService.get<string>('JWT_ACCESS_SECRET'),
          expiresIn: this.configService.get<string>('JWT_ACCESS_EXPIRATION'),
        },
      ),
      // Refresh Token
      this.jwtService.signAsync(
        { sub: userId.toHexString(), email, role },
        {
          secret: this.configService.get<string>('JWT_REFRESH_SECRET'),
          expiresIn: this.configService.get<string>('JWT_REFRESH_EXPIRATION'),
        },
      ),
    ]);

    return { accessToken, refreshToken };
  }

  /**
   * Save or clear hashed refresh token in DB
   */
  async updateRefreshToken(
    userId: Types.ObjectId,
    refreshToken: string | null,
  ): Promise<void> {
    if (refreshToken) {
      const hashedRefreshToken = await this.hashData(refreshToken);
      await this.userService.updateRefreshToken(userId, hashedRefreshToken);
    } else {
      await this.userService.updateRefreshToken(userId, null);
    }
  }

  /**
   * Refresh tokens using a valid refresh token
   */
  async refreshTokens(userId: Types.ObjectId, refreshToken: string) {
    const user = await this.userService.findById(userId);

    if (!user || !user.refreshToken) {
      throw new UnauthorizedException(
        'Access Denied: User not found or refresh token missing.',
      );
    }

    // Check if provided refresh token matches hashed token in DB
    const refreshTokenMatches = await bcrypt.compare(
      refreshToken,
      user.refreshToken,
    );

    if (!refreshTokenMatches) {
      throw new UnauthorizedException('Access Denied: Invalid refresh token.');
    }

    // Generate new tokens and update refresh token in DB
    const tokens = await this.getTokens(user._id, user.email, user.role);
    await this.updateRefreshToken(user._id, tokens.refreshToken);

    return tokens;
  }

  /**
   * Handle user login
   */
  async signIn(signInDto: LoginDto) {
    // 1. Fetch user with password
    const user = await this.userService.findByEmailWithPassword(signInDto.email);
    if (!user) throw new NotFoundException('Incorrect E-Mail');

    // 2. Verify password
    const matchPassword = await bcrypt.compare(signInDto.password, user.password);
    if (!matchPassword) throw new NotFoundException('Incorrect Password');

    // 3. Get user without password
    const userWithoutPassword = await this.userService.findByEmail(signInDto.email);
    if (!userWithoutPassword) return {};
    const result = userWithoutPassword.toObject();

    // 4. Generate tokens
    const tokens = await this.getTokens(
      userWithoutPassword._id,
      userWithoutPassword.email,
      userWithoutPassword.role,
    );

    // 5. Save hashed refresh token
    await this.updateRefreshToken(userWithoutPassword._id, tokens.refreshToken);

    // 6. Return user data and tokens
    return {
      userData: result,
      tokens,
    };
  }
}
