  import { MiddlewareConsumer, Module, RequestMethod } from '@nestjs/common';
  import { AuthController } from './auth.controller';
  import { AuthService } from './auth.service';
  import { UserModule } from 'src/user/user.module';
  import { JwtModule } from '@nestjs/jwt';
  import { ConfigModule } from '@nestjs/config';
  import { AuthTokenMiddleware } from 'src/middlewares/authToken.middleware';

  @Module({
    imports: [UserModule, JwtModule.register({}), ConfigModule],
    controllers: [AuthController],
    providers: [AuthService],
    exports: [AuthService],
  })
  export class AuthModule {

    configure(consumer: MiddlewareConsumer) {
      consumer
        .apply(AuthTokenMiddleware)
        .forRoutes({ path: 'auth/logout', method: RequestMethod.ALL });
    }
  }
