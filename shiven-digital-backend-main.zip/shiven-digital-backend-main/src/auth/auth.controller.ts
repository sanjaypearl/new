import {
  Controller,
  Post,
  Body,
  NotFoundException,
  Res,
  HttpException,
  HttpStatus,
} from '@nestjs/common';
import type { Response } from 'express';
import { AuthService } from './auth.service';
import { Types } from 'mongoose';
import { LoginDto } from './dto/auth.dto';
import { UserService } from 'src/user/user.service';
import { CreateUserDto } from 'src/user/dto/user.dto';
import { Id } from 'src/common/decorators/custom.decorators';
import { ConfigService } from '@nestjs/config';

@Controller('auth')
export class AuthController {
  constructor(
    private authService: AuthService,
    private readonly userService: UserService,
    private configService: ConfigService,
  ) {}

  @Post('register')
  async createUser(@Body() data: CreateUserDto) {
    return await this.userService.createUser(data);
  }

  @Post('login')
  async login(
    @Body() signInDto: LoginDto,
    @Res({ passthrough: true }) res: Response,
  ) {
    const data = await this.authService.signIn(signInDto);

    if (!data || !data.tokens) {
      throw new HttpException(
        'Invalid credentials or tokens not generated.',
        HttpStatus.UNAUTHORIZED,
      );
    }

    const isProduction = !(
      this.configService.get<string | undefined>('NODE_ENV') === 'development'
    );

    // --- Set Access Token Cookie ---
    res.cookie('accessToken', data.tokens.accessToken, {
      httpOnly: true,
      secure: isProduction,
      sameSite: 'strict',
      expires: new Date(Date.now() + 15 * 60 * 1000),
      path: '/',
    });

    // --- Set Refresh Token Cookie ---
    res.cookie('refreshToken', data.tokens.refreshToken, {
      httpOnly: true,
      secure: isProduction,
      sameSite: 'strict',
      expires: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      path: '/',
    });

    return {
      user: data.userData,
      tokens: data.tokens,
    };
  }

  @Post('logout')
  // Add @Res({ passthrough: true }) and the Response type
  async logout(
    @Id() userId: Types.ObjectId,
    @Res({ passthrough: true }) res: Response,
  ) {
    if (userId) {
      // 1. Invalidate the refresh token in your database
      await this.authService.updateRefreshToken(userId, null);

      // 2. Determine if running in production for 'secure' cookie flag
      // This should match how it was determined during login
      const isProduction = !(
      this.configService.get<string | undefined>('NODE_ENV') === 'development'
    );

      // const cookieOptions = {
      //   httpOnly: true,
      //   secure: isProduction,
      //   sameSite: "strict",
      //   path: '/',
      // };

      // 4. Clear the accessToken cookie
      res.clearCookie('accessToken', {
        httpOnly: true,
        secure: isProduction,
        sameSite: "strict",
        path: '/',
      });

      // 5. Clear the refreshToken cookie
      res.clearCookie('refreshToken', {
        httpOnly: true,
        secure: isProduction,
        sameSite: "strict",
        path: '/',
      });

      return { message: 'Logged out successfully' };
    }
    throw new NotFoundException('User Id Not Found');
  }

  // @Post('refresh')
  // async refreshTokens(@Req() req: RequestWithRefreshPayload) {
  //   const userId = req.user.sub;
  //   const refreshToken = req.user.refreshToken; // The raw refresh token from the request

  //   const tokens = await this.authService.refreshTokens(
  //     new Types.ObjectId(userId), // Convert string ID back to ObjectId
  //     refreshToken,
  //   );

  //   return {
  //     message: 'Tokens refreshed successfully',
  //     accessToken: tokens.accessToken,
  //     refreshToken: tokens.refreshToken,
  //   };
  // }
}
