import {
  Injectable,
  NestMiddleware,
  UnauthorizedException,
  Logger,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import { Request, Response, NextFunction } from 'express'; 

@Injectable()
export class AuthTokenMiddleware implements NestMiddleware {
  private readonly logger = new Logger(AuthTokenMiddleware.name);

  constructor(
    private readonly configService: ConfigService,
    private readonly jwtService: JwtService,
  ) {}

  async use(req: Request, res: Response, next: NextFunction) {
    // --- Prioritize getting access token from cookies ---
    const access_token = this.extractAccessToken(req);

    if (!access_token) {
      this.logger.warn('Auth Token Middleware: Access Token not found in cookies or Authorization header.');
      throw new UnauthorizedException('Access token not found.');
    }

    try {
      const jwtSecret = this.configService.get<string>('JWT_ACCESS_SECRET');

      if (!jwtSecret) {
        this.logger.error('JWT_ACCESS_SECRET is not configured.');
        throw new UnauthorizedException('Server configuration error.');
      }

      const decodedToken = this.jwtService.verify(access_token, {
        secret: jwtSecret,
      });


      req.sub = decodedToken.sub; // this is userId (_id in MongoDB)
      req.role = decodedToken.role;
      req.email = decodedToken.email;

      next();
    } catch (error) {
      if (error.name === 'TokenExpiredError') {
        this.logger.warn(`Auth Token Middleware: Access Token expired for user: ${req['sub'] || 'unknown'}.`);
        throw new UnauthorizedException('Access token expired.');
      } else if (error.name === 'JsonWebTokenError') {
        this.logger.warn(`Auth Token Middleware: Invalid access token: ${error.message}.`);
        throw new UnauthorizedException('Invalid access token.');
      } else {
        this.logger.error(`Auth Token Middleware: Unexpected error during token verification: ${error.message}`, error.stack);
        throw new UnauthorizedException('Authentication failed.');
      }
    }
  }

  /**
   * Extracts the access token primarily from cookies, falling back to the Authorization header.
   * @param req The Express Request object.
   * @returns The access token string or undefined if not found.
   */
  private extractAccessToken(req: Request): string | undefined {
    // 1. Try to get from cookies first
    const accessTokenFromCookie = req.cookies?.accessToken; // 'accessToken' should match the cookie name set during login

    if (accessTokenFromCookie) {
      this.logger.debug('Access token found in cookie.');
      return accessTokenFromCookie;
    }

    // 2. If not in cookies, try to get from Authorization header (Bearer token)
    const accessTokenFromHeader = this.extractBearerTokenFromHeader(req);
    if (accessTokenFromHeader) {
      this.logger.debug('Access token found in Authorization header.');
      return accessTokenFromHeader;
    }

    return undefined; // Token not found anywhere
  }

  /**
   * Extracts a Bearer token from the Authorization header.
   * @param req The Express Request object.
   * @returns The Bearer token string or undefined if not found.
   */
  private extractBearerTokenFromHeader(req: Request): string | undefined {
    const [type, token] = req.headers.authorization?.split(' ') ?? [];
    return type === 'Bearer' ? token : undefined;
  }
}