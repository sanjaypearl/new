import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import mongoose, { Document, Types, Schema as MongooseSchema, HydratedDocument } from 'mongoose';

// Existing Enums and Types
export enum PlanDuration {
  ONE_MONTH = 30,
  QUARTER = 90,
  HALF_YEAR = 180,
  ONE_YEAR = 365,
}

export type PlanDurationConfig = {
  duration: number;
  discountType: string;
  discountValue: number;
};

// New Enum for PlanType
export enum PlanType {
  NORMAL = 'normal',
  TRIAL = 'trial',
}

export type PlanDocument = HydratedDocument<Plan>;

@Schema({ timestamps: true })
export class Plan extends Document {
  @Prop({
    type: String,
    required: [true, 'Plan Name is required'],
    trim: true,
  })
  name: string;

  @Prop({
    type: String,
    unique: true,
    trim: true,
    required: [true, 'Plan internal name is required'],
  })
  internalName: string;

  @Prop({
    type: Number,
    min: 1,
    required: [true, 'Plan Amount is required'],
  })
  amount: number;

  @Prop({
    type: Boolean,
    default: true,
  })
  isActive: boolean;

  @Prop({
    type: Number,
    default: 0,
    min: 0,
  })
  sortOrder: number;

  // New Field: planType
  @Prop({
    type: String,
    enum: Object.values(PlanType), // Use the values from the PlanType enum
    default: PlanType.NORMAL, // Default to 'normal'
    required: true, // This field should always be present
  })
  planType: PlanType; // Type it with the enum

  // New Field: planDuration (in days)
  @Prop({
    type: Number,
    min: 0, // Allows 0 for non-trial plans, validation will enforce >0 for trial
    // 'required' is handled by custom validation in the pre-save hook
  })
  planDuration?: number; // Make it optional at the schema level; required conditionally

  @Prop({
    type: Map,
    of: new mongoose.Schema({
      duration: { type: Number, required: true },
      discountType: {
        type: String,
        enum: ['flat', 'percent'],
        required: true,
      },
      discountValue: {
        type: Number,
        required: true,
        min: 0,
      },
    }),
  })
  planDurationConfig?: Map<string, PlanDurationConfig>; // Make it optional at the schema level

}

export const PlanSchema = SchemaFactory.createForClass(Plan);

PlanSchema.pre('save', async function (next) {
  const plan = this as Plan; // Ensure 'this' refers to the Plan document

  try {
    // --- Validation based on planType ---
    if (plan.planType === PlanType.TRIAL) {
      // If planType is 'trial', planDuration is required and must be greater than 0
      if (plan.planDuration === undefined || plan.planDuration <= 0) {
        throw new Error('Trial plans require a planDuration greater than 0.');
      }
      // For trial plans, planDurationConfig should not be used
      if (plan.planDurationConfig && plan.planDurationConfig.size > 0) {
        throw new Error(
          'Trial plans cannot have planDurationConfig specified.',
        );
      }
    } else if (plan.planType === PlanType.NORMAL) {
      // If planType is 'normal'

      // planDuration should not be set for normal plans (as planDurationConfig handles durations)
      if (plan.planDuration !== undefined && plan.planDuration > 0) {
        throw new Error(
          'Normal plans should not have planDuration specified. Use planDurationConfig instead.',
        );
      }

      // planDurationConfig is required for normal plans and must not be empty
      if (!plan.planDurationConfig || plan.planDurationConfig.size === 0) {
        throw new Error(
          'Normal plans require planDurationConfig to be set with at least one duration.',
        );
      }

      // --- Original planDurationConfig validation (for normal plans) ---
      const requiredDurations = [
        'monthly',
        'quarterly',
        'halfyearly',
        'yearly',
      ];
      const durationDays: { [key: string]: number } = {
        monthly: 30,
        quarterly: 90,
        halfyearly: 180,
        yearly: 365,
      };

      for (const key of requiredDurations) {
        // Only validate if the key exists in the map
        if (!plan.planDurationConfig.has(key)) {
          continue; // If a specific key is not present, skip its detailed validation
        }

        const durationConfig = plan.planDurationConfig.get(key);

        // This check ensures 'durationConfig' is not undefined, which should be true if .has(key) is true
        if (!durationConfig) {
          throw new Error(`Duration Config for "${key}" is missing data.`);
        }

        if (durationConfig.duration !== durationDays[key]) {
          throw new Error(
            `The "${key}" duration must be ${durationDays[key]} days.`,
          );
        }

        const { discountType, discountValue } = durationConfig;

        if (discountType === 'percent' && discountValue > 100) {
          throw new Error(
            `The discount value for "${key}" cannot exceed 100% if the discount type is "percent".`,
          );
        }

        // Flat discount cannot exceed the base plan amount
        if (discountType === 'flat' && discountValue > plan.amount) {
          throw new Error(
            `The discount value for "${key}" cannot exceed the plan amount (${plan.amount}) if the discount type is "flat".`,
          );
        }

      }
    }

    next(); // Proceed with save operation
  } catch (err) {
    next(err); // Pass validation error to Mongoose
  }
});

// Existing indexes
PlanSchema.index({ name: 1, planType: 1 });
PlanSchema.index({ amount: 1 });
