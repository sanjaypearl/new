import {
  Body,
  Controller,
  Post,
  Get,
  Param,
  UseGuards,
  Patch,
  Delete,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { CreatePlanDto, UpdatePlanDto } from './dto/create-plan.dto';
import { PlanService } from './plan.service';
import { Plan } from './plan.schema';
import { RolesGuard } from 'src/common/guards/roles.guard';
import { Roles } from 'src/common/decorators/custom.decorators';

@Controller('plans')
@UseGuards(RolesGuard)
export class PlanController {
  constructor(private readonly plansService: PlanService) {}

  @Post()
  @Roles('admin')
  async create(@Body() createPlanDto: CreatePlanDto): Promise<Plan> {
    return this.plansService.createPlan(createPlanDto);
  }

  @Get()
  async findAll(): Promise<Plan[]> {
    return this.plansService.findAll();
  }

  @Get(':id')
  async findOne(@Param('id') id: string): Promise<Plan> {
    return this.plansService.findOne(id);
  }

  @Patch(':id') // Use PATCH for partial updates
  @Roles('admin') // Only admins can update plans
  async update(
    @Param('id') id: string,
    @Body() updatePlanDto: UpdatePlanDto,
  ): Promise<Plan> {
    return this.plansService.updatePlan(id, updatePlanDto);
  }

  @Delete(':id') // Use DELETE for deleting resources
  @Roles('admin') // Only admins can delete plans
  @HttpCode(HttpStatus.NO_CONTENT) // Indicate successful deletion without a response body
  async delete(@Param('id') id: string): Promise<void> {
    // Return void as response body is empty
    await this.plansService.deletePlan(id);
    // NestJS will automatically send 204 No Content if void is returned and HttpCode is set
  }
}
