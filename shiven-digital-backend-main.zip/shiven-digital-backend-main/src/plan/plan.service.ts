// src/plans/plans.service.ts
import {
  Injectable,
  BadRequestException,
  ConflictException,
  NotFoundException, // Use NotFoundException for consistency
} from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import mongoose, { Model } from 'mongoose';
import { CreatePlanDto, UpdatePlanDto } from './dto/create-plan.dto';
import { Plan, PlanDocument } from './plan.schema';

@Injectable()
export class PlanService {
  constructor(@InjectModel(Plan.name) private planModel: Model<PlanDocument>) {}

  async createPlan(createPlanDto: CreatePlanDto): Promise<Plan> {
    const existingPlan = await this.planModel.findOne({
      internalName: createPlanDto.internalName,
    });

    if (existingPlan) {
      throw new ConflictException(
        'Plan with this internal name already exists.',
      );
    }

    const createdPlan = new this.planModel(createPlanDto);
    return await createdPlan.save();
  }

  async findAll(): Promise<Plan[]> {
    return this.planModel.find().exec();
  }

  async findOne(id: string): Promise<Plan> {
    // Check if ID is a valid MongoDB ObjectId format
    if (!mongoose.isValidObjectId(id)) {
      throw new BadRequestException(`Invalid Plan ID format: ${id}`);
    }

    const plan = await this.planModel.findById(id).exec();
    if (!plan) {
      throw new NotFoundException(`Plan with ID ${id} not found.`); // Use NotFoundException
    }
    return plan;
  }

  async updatePlan(id: string, updatePlanDto: UpdatePlanDto): Promise<Plan> {
    // 1. Validate ID format
    if (!mongoose.isValidObjectId(id)) {
      throw new BadRequestException(`Invalid Plan ID format: ${id}`);
    }

    // 2. Check for unique internalName conflict if it's being updated
    if (updatePlanDto.internalName) {
      const existingPlan = await this.planModel.findOne({
        internalName: updatePlanDto.internalName,
        _id: { $ne: id }, // Exclude the current plan itself
      });
      if (existingPlan) {
        throw new ConflictException(
          'Another plan with this internal name already exists.',
        );
      }
    }

    const plan = await this.planModel.findById(id).exec();

    if (!plan) {
      throw new NotFoundException(`Plan with ID ${id} not found.`);
    }

    // Apply the updates from the DTO to the retrieved document
    // Object.assign handles merging properties correctly
    Object.assign(plan, updatePlanDto);

    try {
      return await plan.save();
    } catch (error) {
      if (error.name === 'ValidationError') {
        throw new BadRequestException(error.message);
      }
      throw error;
    }
  }

  async deletePlan(id: string): Promise<{ message: string }> {
    // 1. Validate ID format
    if (!mongoose.isValidObjectId(id)) {
      throw new BadRequestException(`Invalid Plan ID format: ${id}`);
    }

    // 2. Find and delete the document
    const result = await this.planModel.findByIdAndDelete(id).exec();

    if (!result) {
      throw new NotFoundException(`Plan with ID ${id} not found.`);
    }

    return { message: 'Plan deleted successfully.' };
  }
}