// src/plans/dto/create-plan.dto.ts
import {
  IsString,
  IsNotEmpty,
  IsNumber,
  Min,
  IsBoolean,
  IsEnum,
  IsPositive,
  ValidateIf,
  ValidateNested,
  IsObject,
  IsDefined,
  IsNotEmptyObject,
  IsOptional,
  MinLength,
} from 'class-validator';
import { Type } from 'class-transformer';
import { PlanType } from '../plan.schema';
export class PlanDurationConfigDto {
  @IsNumber()
  @IsPositive()  
  duration: number;

  @IsString()
  @IsEnum(['flat', 'percent'], { message: 'Discount type must be "flat" or "percent"' })
  discountType: string;

  @IsNumber()
  @Min(0)
  discountValue: number;
}

export class CreatePlanDto {
  @IsString()
  @IsNotEmpty()
  @MinLength(3, { message: 'Plan name must be at least 3 characters long' })
  name: string;

  @IsString()
  @IsNotEmpty()
  @MinLength(3, { message: 'Internal name must be at least 3 characters long' })
  internalName: string;

  @IsNumber()
  @IsPositive({ message: 'Plan amount must be a positive number' }) // min: 1 from schema
  amount: number;

  @IsBoolean()
  @IsOptional() // Has a default value in schema, so optional on creation
  isActive?: boolean;

  @IsNumber()
  @Min(0)
  @IsOptional() // Has a default value in schema, so optional on creation
  sortOrder?: number;

  @IsEnum(PlanType, { message: 'Invalid plan type. Must be "normal" or "trial".' })
  planType: PlanType;

  @ValidateIf((o) => o.planType === PlanType.TRIAL)
  @IsNumber()
  @IsPositive({ message: 'Trial plans require a positive plan duration.' })
  @IsDefined({ message: 'Trial plans require planDuration to be defined.' })
  planDuration?: number;

  @ValidateIf((o) => o.planType === PlanType.NORMAL)
  @IsObject({ message: 'Plan duration config must be an object.' })
  @IsDefined({ message: 'Normal plans require planDurationConfig to be set.' })
//   @IsNotEmptyObject({nullable: false}, { message: 'Normal plans require planDurationConfig with at least one duration.' })
//   @ValidateNested({ each: true }) 
//   @Type(() => PlanDurationConfigDto) 
  planDurationConfig?: Record<string, PlanDurationConfigDto>; 
}


export class UpdatePlanDto {
  @IsString()
  @IsNotEmpty()
  @MinLength(3, { message: 'Plan name must be at least 3 characters long' })
  @IsOptional() // All fields are optional for update
  name?: string;

  @IsString()
  @IsNotEmpty()
  @MinLength(3, { message: 'Internal name must be at least 3 characters long' })
  @IsOptional()
  internalName?: string; // Note: Updating unique fields needs careful handling (see service)

  @IsNumber()
  @IsPositive({ message: 'Plan amount must be a positive number' })
  @IsOptional()
  amount?: number;

  @IsBoolean()
  @IsOptional()
  isActive?: boolean;

  @IsNumber()
  @Min(0)
  @IsOptional()
  sortOrder?: number;

  @IsEnum(PlanType, { message: 'Invalid plan type. Must be "normal" or "trial".' })
  @IsOptional()
  planType?: PlanType; // Changing planType might invalidate other fields, careful updates needed

  @ValidateIf((o) => o.planType === PlanType.TRIAL || (o.planType === undefined && o.planDuration !== undefined))
  @IsNumber()
  @IsPositive({ message: 'Trial plans require a positive plan duration.' })
  @IsDefined({ message: 'Trial plans require planDuration to be defined.' })
  @IsOptional() // Optional as it might not be provided in the update, but still conditionally validated if present.
  planDuration?: number;

  @ValidateIf((o) => o.planType === PlanType.NORMAL || (o.planType === undefined && o.planDurationConfig !== undefined))
  @IsObject({ message: 'Plan duration config must be an object.' })
  @IsDefined({ message: 'Normal plans require planDurationConfig to be set.' })
  // @IsNotEmptyObject({nullable: false}, { message: 'Normal plans require planDurationConfig with at least one duration.' })
  // @ValidateNested({ each: true })
  // @Type(() => PlanDurationConfigDto)
  @IsOptional() // Optional as it might not be provided in the update
  planDurationConfig?: Record<string, PlanDurationConfigDto>;
}