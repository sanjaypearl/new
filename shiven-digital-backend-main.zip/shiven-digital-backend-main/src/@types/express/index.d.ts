
declare namespace Express {
  interface Request {
    sub?: string; // Or a more specific type if you know it, e.g., userId: string
    role?: string; // Or a more specific enum/union type
    email?: string;
  }
}