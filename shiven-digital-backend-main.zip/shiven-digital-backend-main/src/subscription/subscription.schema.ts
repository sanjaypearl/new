import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types, Schema as MongooseSchema } from 'mongoose';
import { Plan } from 'src/plan/plan.schema';
import { User } from 'src/user/user.schema';

@Schema({ timestamps: true })
export class Subscription extends Document {
  @Prop({ type: Types.ObjectId, ref: User.name, required: true })
  userId: Types.ObjectId; 

  @Prop({
    type: Types.ObjectId,
    ref: Plan.name,
    required: true,
  })
  planId: Types.ObjectId; // Linked plan

  @Prop({
    type: Date,
    default: Date.now,
    required: true,
  })
  startDate: Date;

  @Prop({ type: Date, required: true })
  expiryDate: Date;

}

const SubscriptionSchema = SchemaFactory.createForClass(Subscription);

SubscriptionSchema.index({ userId: 1 }, { unique: true });
SubscriptionSchema.index({ planId: 1 });
SubscriptionSchema.index({ userId: 1, planId: 1 });

SubscriptionSchema.pre('save', function (next) {
  if (typeof this.userId === 'string') {
    this.userId = new Types.ObjectId(`${this.userId}`);
  }
  if (typeof this.planId === 'string') {
    this.planId = new Types.ObjectId(`${this.planId}`);
  }
  next();
});

SubscriptionSchema.methods.isExpired = function (): boolean {
  const now = new Date();
  return this.expiryDate < now;
};

export { SubscriptionSchema };