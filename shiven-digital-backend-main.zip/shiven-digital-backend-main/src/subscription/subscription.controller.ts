import { Controller } from '@nestjs/common';

@Controller('subscription')
export class SubscriptionController {}
